function smallButtonAction() {
    alert('FELICIDADES ENCONTRASTE EL BOTTON CORRECTO');
}

function handleLogin() {
    alert('Intento de login');
}
